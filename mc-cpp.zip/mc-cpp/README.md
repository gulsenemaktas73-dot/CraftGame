# Voxel Dünyası (C++ / OpenGL)

Bedrock'ın kod dili olan **C++** ile yazılmış, gerçek bir OpenGL voxel oyunu.
Sonsuz chunk sistemi, mağara/cevher üretimi, blok kırma-koyma, gündüz-gece
döngüsü ve 27 farklı blok türü içerir.

## GitHub'a yükleme (eve gidince derleyeceksin)

Bu klasörü bir GitHub deposuna yükle, sonra evdeki bilgisayarında `git clone`
ile indirip derlersin:

```bash
cd mc-cpp
git init
git add .
git commit -m "Voxel Dunyasi - ilk surum"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/voxel-dunyasi.git
git push -u origin main
```

(`KULLANICI_ADIN` yerine kendi GitHub kullanıcı adını, önce GitHub'da boş bir
repo oluşturman gerekiyor — "New repository" diyip isim veriyorsun, README
eklemeden oluştur.)

**Önemli:** GitHub'ın kendisi bu oyunu senin için çalıştıramaz — bu masaüstü
bir uygulama, ekran/pencere gerektiriyor, tarayıcıda veya Codespaces'te
"oynanamaz". Ama ekledğim `.github/workflows/build.yml` sayesinde her push
attığında GitHub kendi sunucusunda kodu otomatik derler (Actions sekmesinde
yeşil tik ✅ / kırmızı çarpı ❌ görürsün). Böylece eve gitmeden önce kodun
gerçekten derlenip derlenmediğini görebilirsin — ben bu ortamda GLFW/GLEW
kurup deneyemedim, bu yüzden bu otomatik kontrol senin için de faydalı bir
doğrulama olacak. Derleme hata verirse Actions sekmesindeki log'u bana
yapıştır, birlikte düzeltiriz.

Eve varınca yukarıdaki `git clone` ile indirip aşağıdaki adımlarla derlersin.

Bu bir **kaynak kod projesidir** — dosyayı çift tıklayıp açamazsın, kendi
bilgisayarında derlemen (compile) gerekiyor. Aşağıda üç işletim sistemi için
adım adım talimat var.

## Gerekli kütüphaneler

- GLFW3 (pencere + girdi)
- GLEW (OpenGL fonksiyon yükleyici)
- GLM (matematik kütüphanesi, sadece header dosyaları)
- Bir C++17 derleyicisi (g++, clang++ veya MSVC)

## Windows (vcpkg + Visual Studio veya MinGW)

```powershell
git clone https://github.com/microsoft/vcpkg
.\vcpkg\bootstrap-vcpkg.bat
.\vcpkg\vcpkg install glfw3 glew glm --triplet x64-windows

cmake -B build -S . -DCMAKE_TOOLCHAIN_FILE=vcpkg/scripts/buildsystems/vcpkg.cmake
cmake --build build --config Release
build\Release\VoxelDunyasi.exe
```

## Linux (Ubuntu/Debian)

```bash
sudo apt update
sudo apt install build-essential cmake libglfw3-dev libglew-dev libglm-dev

cmake -B build -S .
cmake --build build -j4
./build/VoxelDunyasi
```

Eğer CMake kütüphaneleri bulamazsa, doğrudan g++ ile de derleyebilirsin:

```bash
g++ src/main.cpp -o VoxelDunyasi -std=c++17 -Isrc \
    $(pkg-config --cflags glfw3 glew) \
    $(pkg-config --libs glfw3 glew) -lGL -ldl -lpthread -lX11
./VoxelDunyasi
```

## macOS (Homebrew)

```bash
brew install cmake glfw glew glm

cmake -B build -S .
cmake --build build -j4
./build/VoxelDunyasi
```

## Kontroller

| Tuş / Fare        | Aksiyon                          |
|-------------------|-----------------------------------|
| W A S D           | Hareket                          |
| Fare              | Etrafa bakma                     |
| Space             | Zıpla                             |
| Sol Shift         | Koşma (sprint)                   |
| Sol tık           | Blok kır                         |
| Sağ tık           | Blok koy (seçili eşya)            |
| 1-9 veya scroll   | Envanterden blok seç              |
| Esc               | Çıkış                            |

Pencere başlığında (title bar) FPS, seçili blok, koordinat ve gündüz/gece
bilgisi anlık olarak güncellenir — ayrı bir metin render sistemi
kurmadığımız için basit ve pratik bir HUD çözümü bu.

## Neler var

- **Sonsuz dünya**: oyuncu etrafında chunk'lar (16x16x128) anlık üretilir,
  uzaklaşınca bellekten kaldırılır (performans için).
- **Gerçekçi(-imsi) görünüm**: yön bazlı gölgelendirme (üst/yan/alt yüzler
  farklı parlaklıkta), blok başına hafif renk varyasyonu, mesafeye göre sis
  (fog) ve yumuşak gündüz-gece geçişi.
- **27 blok türü**: çim, toprak, taş, kum, çakıl, kil, su, meşe/huş
  kütük-yaprak, bedrock, kömür/demir/altın/elmas/zümrüt/redstone cevheri,
  kar, buz, cam, tahta, tuğla, obsidyen, yosunlu taş, mermer, bazalt.
- **Mağaralar ve cevher damarları**: 3D gürültü (noise) ile oyulmuş mağaralar,
  derinliğe göre değişen cevher olasılıkları.
- **Ağaçlar**: nem (moisture) gürültüsüne göre meşe veya huş ağacı.

## Bilinen sınırlamalar (bilerek basit tutulan kısımlar)

- Ekranda gerçek bir HUD/metin yok; bilgiler pencere başlığında gösteriliyor.
  İstersen ileride `stb_truetype` veya `FreeType` ile ekran içi yazı
  ekleyebiliriz.
- Ağaçlar chunk kenarına çok yakın yerlerde büyümüyor (komşu chunk henüz
  üretilmemişken taşmayı önlemek için bilinçli bir basitleştirme).
- Su statik; akış/dalga fiziği yok.
- Gökyüzü düz bir renk + sis ile simüle ediliyor, gerçek bir skybox mesh'i
  veya bulut sistemi yok.

Bunların hepsi genişletilebilir — hangisini istersen bir sonraki adımda
ekleyebilirim.
