#pragma once
// Classic improved Perlin noise (Ken Perlin, 2002) + fractal Brownian motion helpers.
// Used for terrain height maps, cave carving and ore vein placement.

#include <cmath>
#include <cstdint>
#include <cstring>

class Noise {
public:
    explicit Noise(uint32_t seed = 1337) {
        for (int i = 0; i < 256; ++i) perm[i] = static_cast<uint8_t>(i);
        // simple xorshift based shuffle so results are deterministic per-seed
        uint32_t s = seed ? seed : 1;
        for (int i = 255; i > 0; --i) {
            s ^= s << 13; s ^= s >> 17; s ^= s << 5;
            int j = static_cast<int>(s % static_cast<uint32_t>(i + 1));
            uint8_t tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp;
        }
        for (int i = 0; i < 256; ++i) perm[256 + i] = perm[i];
    }

    // 3D Perlin noise, range roughly [-1, 1]
    double noise3(double x, double y, double z) const {
        int X = static_cast<int>(std::floor(x)) & 255;
        int Y = static_cast<int>(std::floor(y)) & 255;
        int Z = static_cast<int>(std::floor(z)) & 255;
        x -= std::floor(x); y -= std::floor(y); z -= std::floor(z);
        double u = fade(x), v = fade(y), w = fade(z);
        int A  = perm[X] + Y,  AA = perm[A] + Z, AB = perm[A + 1] + Z;
        int B  = perm[X + 1] + Y, BA = perm[B] + Z, BB = perm[B + 1] + Z;

        return lerp(w,
            lerp(v,
                lerp(u, grad(perm[AA], x, y, z),     grad(perm[BA], x - 1, y, z)),
                lerp(u, grad(perm[AB], x, y - 1, z), grad(perm[BB], x - 1, y - 1, z))),
            lerp(v,
                lerp(u, grad(perm[AA + 1], x, y, z - 1),     grad(perm[BA + 1], x - 1, y, z - 1)),
                lerp(u, grad(perm[AB + 1], x, y - 1, z - 1), grad(perm[BB + 1], x - 1, y - 1, z - 1))));
    }

    double noise2(double x, double z) const { return noise3(x, 0.0, z); }

    // Fractal Brownian motion: layered noise for natural-looking terrain
    double fbm2(double x, double z, int octaves, double persistence, double lacunarity) const {
        double total = 0, amp = 1, freq = 1, maxVal = 0;
        for (int i = 0; i < octaves; ++i) {
            total += noise2(x * freq, z * freq) * amp;
            maxVal += amp;
            amp *= persistence;
            freq *= lacunarity;
        }
        return total / maxVal;
    }

    double fbm3(double x, double y, double z, int octaves, double persistence, double lacunarity) const {
        double total = 0, amp = 1, freq = 1, maxVal = 0;
        for (int i = 0; i < octaves; ++i) {
            total += noise3(x * freq, y * freq, z * freq) * amp;
            maxVal += amp;
            amp *= persistence;
            freq *= lacunarity;
        }
        return total / maxVal;
    }

private:
    uint8_t perm[512];

    static double fade(double t) { return t * t * t * (t * (t * 6 - 15) + 10); }
    static double lerp(double t, double a, double b) { return a + t * (b - a); }
    static double grad(int hash, double x, double y, double z) {
        int h = hash & 15;
        double u = h < 8 ? x : y;
        double v = h < 4 ? y : (h == 12 || h == 14 ? x : z);
        return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
    }
};
