#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <algorithm>
#include <cmath>

class Camera {
public:
    glm::vec3 position{0, 70, 0};
    float yaw = -90.0f;   // degrees, facing -Z at yaw=-90
    float pitch = 0.0f;
    float mouseSensitivity = 0.12f;

    glm::vec3 front() const {
        glm::vec3 f;
        f.x = std::cos(glm::radians(yaw)) * std::cos(glm::radians(pitch));
        f.y = std::sin(glm::radians(pitch));
        f.z = std::sin(glm::radians(yaw)) * std::cos(glm::radians(pitch));
        return glm::normalize(f);
    }

    glm::vec3 right() const {
        return glm::normalize(glm::cross(front(), glm::vec3(0, 1, 0)));
    }

    void processMouse(double dx, double dy) {
        yaw += static_cast<float>(dx) * mouseSensitivity;
        pitch -= static_cast<float>(dy) * mouseSensitivity;
        pitch = std::clamp(pitch, -89.0f, 89.0f);
    }

    // Eye position is slightly above the collision-box "position" (feet).
    glm::mat4 viewMatrix(float eyeHeight) const {
        glm::vec3 eye = position + glm::vec3(0, eyeHeight, 0);
        return glm::lookAt(eye, eye + front(), glm::vec3(0, 1, 0));
    }
};
