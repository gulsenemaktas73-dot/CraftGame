#pragma once
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <string>

// Vertex layout: position(3) normal(3) color(3) aoShade(1)
inline const char* CHUNK_VERT_SRC = R"GLSL(
#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec3 aColor;
layout(location = 3) in float aShade;

uniform mat4 uView;
uniform mat4 uProj;

out vec3 vColor;
out vec3 vNormal;
out float vShade;
out float vViewDist;

void main() {
    vec4 viewPos = uView * vec4(aPos, 1.0);
    gl_Position = uProj * viewPos;
    vColor = aColor;
    vNormal = aNormal;
    vShade = aShade;
    vViewDist = length(viewPos.xyz);
}
)GLSL";

inline const char* CHUNK_FRAG_SRC = R"GLSL(
#version 330 core
in vec3 vColor;
in vec3 vNormal;
in float vShade;
in float vViewDist;

uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uAmbient;
uniform vec3 uFogColor;
uniform float uFogDensity;

out vec4 FragColor;

void main() {
    float diffuse = max(dot(normalize(vNormal), normalize(uSunDir)), 0.0);
    vec3 lit = uAmbient + uSunColor * diffuse;
    vec3 base = vColor * vShade * lit;

    // exponential-squared fog for a soft realistic horizon
    float fogFactor = 1.0 - exp(-pow(uFogDensity * vViewDist, 2.0));
    fogFactor = clamp(fogFactor, 0.0, 1.0);

    vec3 finalColor = mix(base, uFogColor, fogFactor);
    FragColor = vec4(finalColor, 1.0);
}
)GLSL";

class Shader {
public:
    GLuint id = 0;

    void build(const char* vertSrc, const char* fragSrc) {
        GLuint vert = compile(GL_VERTEX_SHADER, vertSrc);
        GLuint frag = compile(GL_FRAGMENT_SHADER, fragSrc);
        id = glCreateProgram();
        glAttachShader(id, vert);
        glAttachShader(id, frag);
        glLinkProgram(id);
        GLint ok;
        glGetProgramiv(id, GL_LINK_STATUS, &ok);
        if (!ok) {
            char log[1024];
            glGetProgramInfoLog(id, 1024, nullptr, log);
            std::cerr << "Shader link error:\n" << log << std::endl;
        }
        glDeleteShader(vert);
        glDeleteShader(frag);
    }

    void use() const { glUseProgram(id); }

    void setMat4(const char* name, const glm::mat4& m) const {
        glUniformMatrix4fv(glGetUniformLocation(id, name), 1, GL_FALSE, glm::value_ptr(m));
    }
    void setVec3(const char* name, const glm::vec3& v) const {
        glUniform3fv(glGetUniformLocation(id, name), 1, glm::value_ptr(v));
    }
    void setFloat(const char* name, float v) const {
        glUniform1f(glGetUniformLocation(id, name), v);
    }

private:
    static GLuint compile(GLenum type, const char* src) {
        GLuint shader = glCreateShader(type);
        glShaderSource(shader, 1, &src, nullptr);
        glCompileShader(shader);
        GLint ok;
        glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
        if (!ok) {
            char log[1024];
            glGetShaderInfoLog(shader, 1024, nullptr, log);
            std::cerr << "Shader compile error:\n" << log << std::endl;
        }
        return shader;
    }
};
