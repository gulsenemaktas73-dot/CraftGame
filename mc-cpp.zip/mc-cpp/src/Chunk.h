#pragma once
#include <GL/glew.h>
#include <vector>
#include "Block.h"

constexpr int CHUNK_SX = 16;
constexpr int CHUNK_SZ = 16;
constexpr int CHUNK_SY = 128;

class Chunk {
public:
    int cx, cz; // chunk grid coordinates (world block coord = c*CHUNK_S + local)
    std::vector<BlockType> blocks;
    bool dirty = true;
    bool hasMesh = false;
    GLuint vao = 0, vbo = 0, ebo = 0;
    GLsizei indexCount = 0;

    Chunk(int chunkX, int chunkZ) : cx(chunkX), cz(chunkZ) {
        blocks.assign(static_cast<size_t>(CHUNK_SX) * CHUNK_SY * CHUNK_SZ, BlockType::AIR);
        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);
        glGenBuffers(1, &ebo);
    }

    ~Chunk() {
        if (vao) glDeleteVertexArrays(1, &vao);
        if (vbo) glDeleteBuffers(1, &vbo);
        if (ebo) glDeleteBuffers(1, &ebo);
    }

    // non-copyable (owns GL resources)
    Chunk(const Chunk&) = delete;
    Chunk& operator=(const Chunk&) = delete;

    static inline int index(int lx, int ly, int lz) {
        return (ly * CHUNK_SZ + lz) * CHUNK_SX + lx;
    }

    BlockType localGet(int lx, int ly, int lz) const {
        if (lx < 0 || lx >= CHUNK_SX || ly < 0 || ly >= CHUNK_SY || lz < 0 || lz >= CHUNK_SZ)
            return BlockType::AIR;
        return blocks[index(lx, ly, lz)];
    }

    void localSet(int lx, int ly, int lz, BlockType b) {
        if (lx < 0 || lx >= CHUNK_SX || ly < 0 || ly >= CHUNK_SY || lz < 0 || lz >= CHUNK_SZ) return;
        blocks[index(lx, ly, lz)] = b;
        dirty = true;
    }
};
