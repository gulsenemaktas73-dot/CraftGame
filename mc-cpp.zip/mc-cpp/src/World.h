#pragma once
#include <unordered_map>
#include <memory>
#include <vector>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <algorithm>
#include <glm/glm.hpp>
#include "Chunk.h"
#include "Block.h"
#include "Noise.h"
#include "Shader.h"

inline int floorDiv(int a, int b) {
    int d = a / b, r = a % b;
    return (r != 0 && ((r < 0) != (b < 0))) ? d - 1 : d;
}
inline int floorMod(int a, int b) {
    int m = a % b;
    return (m < 0) ? m + b : m;
}

// Deterministic pseudo-random float in [0,1) from integer coordinates.
inline float hashToFloat(int x, int y, int z, uint32_t seed) {
    uint32_t h = seed;
    h ^= static_cast<uint32_t>(x) * 374761393u;
    h ^= static_cast<uint32_t>(y) * 668265263u;
    h ^= static_cast<uint32_t>(z) * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h ^= (h >> 16);
    return static_cast<float>(h % 1000000u) / 1000000.0f;
}

struct RaycastHit {
    bool hit = false;
    glm::ivec3 block{0};
    glm::ivec3 prev{0}; // block position to place a new block into
};

struct FaceDef {
    glm::vec3 normal;
    glm::vec3 corners[4]; // relative to block min corner, CCW when viewed from outside
    float baseShade;
};

// 6 faces of a unit cube. Order: +Y, -Y, +X, -X, +Z, -Z
// Winding is CCW as seen from outside (from the direction the normal points),
// which matches OpenGL's default front-face + back-face culling setup.
static const FaceDef FACES[6] = {
    { { 0, 1, 0}, { {0,1,0},{0,1,1},{1,1,1},{1,1,0} }, 1.00f }, // top
    { { 0,-1, 0}, { {0,0,1},{0,0,0},{1,0,0},{1,0,1} }, 0.50f }, // bottom
    { { 1, 0, 0}, { {1,0,0},{1,1,0},{1,1,1},{1,0,1} }, 0.82f }, // +X
    { {-1, 0, 0}, { {0,0,1},{0,1,1},{0,1,0},{0,0,0} }, 0.75f }, // -X
    { { 0, 0, 1}, { {1,0,1},{1,1,1},{0,1,1},{0,0,1} }, 0.90f }, // +Z
    { { 0, 0,-1}, { {0,0,0},{0,1,0},{1,1,0},{1,0,0} }, 0.68f }, // -Z
};

class World {
public:
    explicit World(uint32_t seed = 1337) : noise(seed), caveNoise(seed + 91), seed(seed) {}

    static constexpr int SEA_LEVEL = 44;

    BlockType getBlock(int wx, int wy, int wz) const {
        if (wy < 0 || wy >= CHUNK_SY) return BlockType::AIR;
        int cx = floorDiv(wx, CHUNK_SX), cz = floorDiv(wz, CHUNK_SZ);
        auto it = chunks.find(key(cx, cz));
        if (it == chunks.end()) return BlockType::AIR;
        return it->second->localGet(floorMod(wx, CHUNK_SX), wy, floorMod(wz, CHUNK_SZ));
    }

    void setBlock(int wx, int wy, int wz, BlockType b) {
        if (wy < 0 || wy >= CHUNK_SY) return;
        int cx = floorDiv(wx, CHUNK_SX), cz = floorDiv(wz, CHUNK_SZ);
        auto it = chunks.find(key(cx, cz));
        if (it == chunks.end()) return;
        int lx = floorMod(wx, CHUNK_SX), lz = floorMod(wz, CHUNK_SZ);
        it->second->localSet(lx, wy, lz, b);
        // dirty neighbouring chunk too if we edited a boundary block, to avoid seams
        if (lx == 0) markDirty(cx - 1, cz);
        if (lx == CHUNK_SX - 1) markDirty(cx + 1, cz);
        if (lz == 0) markDirty(cx, cz - 1);
        if (lz == CHUNK_SZ - 1) markDirty(cx, cz + 1);
    }

    int highestSolidY(int wx, int wz) {
        int cx = floorDiv(wx, CHUNK_SX), cz = floorDiv(wz, CHUNK_SZ);
        getOrCreateChunk(cx, cz);
        for (int y = CHUNK_SY - 1; y >= 0; --y) {
            if (isSolid(getBlock(wx, y, wz))) return y;
        }
        return 0;
    }

    // Loads chunks around the player, unloads far ones, rebuilds a limited
    // number of dirty meshes per call so the frame rate stays smooth.
    void update(const glm::vec3& playerPos, int renderDistance) {
        int pcx = floorDiv(static_cast<int>(std::floor(playerPos.x)), CHUNK_SX);
        int pcz = floorDiv(static_cast<int>(std::floor(playerPos.z)), CHUNK_SZ);

        int generated = 0;
        const int maxGenPerFrame = 3;
        for (int r = 0; r <= renderDistance && generated < maxGenPerFrame; ++r) {
            for (int dx = -r; dx <= r && generated < maxGenPerFrame; ++dx) {
                for (int dz = -r; dz <= r && generated < maxGenPerFrame; ++dz) {
                    if (std::max(std::abs(dx), std::abs(dz)) != r) continue;
                    int cx = pcx + dx, cz = pcz + dz;
                    if (chunks.find(key(cx, cz)) == chunks.end()) {
                        getOrCreateChunk(cx, cz);
                        ++generated;
                    }
                }
            }
        }

        // unload far chunks
        std::vector<int64_t> toRemove;
        for (auto& kv : chunks) {
            int dx = kv.second->cx - pcx, dz = kv.second->cz - pcz;
            if (std::max(std::abs(dx), std::abs(dz)) > renderDistance + 2) toRemove.push_back(kv.first);
        }
        for (auto k : toRemove) chunks.erase(k);

        int rebuilt = 0;
        const int maxMeshPerFrame = 4;
        for (auto& kv : chunks) {
            if (kv.second->dirty && rebuilt < maxMeshPerFrame) {
                buildMesh(*kv.second);
                rebuilt++;
            }
        }
    }

    void render(const Shader& shader) const {
        for (auto& kv : chunks) {
            const Chunk& c = *kv.second;
            if (!c.hasMesh || c.indexCount == 0) continue;
            glBindVertexArray(c.vao);
            glDrawElements(GL_TRIANGLES, c.indexCount, GL_UNSIGNED_INT, nullptr);
        }
        glBindVertexArray(0);
    }

    // Fixed-step raymarch for block breaking/placing (simple and fast enough
    // at this scale; a full DDA voxel traversal would be more precise but
    // isn't needed for a ~6 block interaction range).
    RaycastHit raycast(glm::vec3 origin, glm::vec3 dir, float maxDist) {
        RaycastHit result;
        glm::ivec3 prevCell(std::floor(origin.x), std::floor(origin.y), std::floor(origin.z));
        const float step = 0.05f;
        for (float t = 0; t < maxDist; t += step) {
            glm::vec3 p = origin + dir * t;
            glm::ivec3 cell(std::floor(p.x), std::floor(p.y), std::floor(p.z));
            if (isSolid(getBlock(cell.x, cell.y, cell.z))) {
                result.hit = true;
                result.block = cell;
                result.prev = prevCell;
                return result;
            }
            prevCell = cell;
        }
        return result;
    }

private:
    std::unordered_map<int64_t, std::unique_ptr<Chunk>> chunks;
    Noise noise;
    Noise caveNoise;
    uint32_t seed;

    static int64_t key(int cx, int cz) {
        return (static_cast<int64_t>(static_cast<uint32_t>(cx)) << 32) | static_cast<uint32_t>(cz);
    }

    void markDirty(int cx, int cz) {
        auto it = chunks.find(key(cx, cz));
        if (it != chunks.end()) it->second->dirty = true;
    }

    Chunk& getOrCreateChunk(int cx, int cz) {
        auto it = chunks.find(key(cx, cz));
        if (it != chunks.end()) return *it->second;
        auto chunk = std::make_unique<Chunk>(cx, cz);
        generateTerrain(*chunk);
        Chunk& ref = *chunk;
        chunks[key(cx, cz)] = std::move(chunk);
        return ref;
    }

    int surfaceHeight(int wx, int wz) const {
        double h = noise.fbm2(wx * 0.008, wz * 0.008, 4, 0.5, 2.0) * 24.0;
        h += noise.fbm2(wx * 0.05, wz * 0.05, 3, 0.5, 2.0) * 4.0;
        int height = static_cast<int>(SEA_LEVEL + 8 + h);
        return std::clamp(height, 6, CHUNK_SY - 12);
    }

    BlockType pickOre(int wx, int wy, int wz) const {
        float r = hashToFloat(wx, wy, wz, seed);
        if (wy <= 14) {
            if (r < 0.010f) return BlockType::DIAMOND_ORE;
            if (r < 0.030f) return BlockType::GOLD_ORE;
            if (r < 0.055f) return BlockType::REDSTONE_ORE;
            if (r < 0.100f) return BlockType::IRON_ORE;
            if (r < 0.160f) return BlockType::COAL_ORE;
        } else if (wy <= 34) {
            if (r < 0.010f) return BlockType::GOLD_ORE;
            if (r < 0.022f) return BlockType::REDSTONE_ORE;
            if (r < 0.065f) return BlockType::IRON_ORE;
            if (r < 0.130f) return BlockType::COAL_ORE;
        } else if (wy <= 64) {
            if (r < 0.006f) return BlockType::EMERALD_ORE;
            if (r < 0.050f) return BlockType::IRON_ORE;
            if (r < 0.120f) return BlockType::COAL_ORE;
        } else {
            if (r < 0.080f) return BlockType::COAL_ORE;
        }
        return BlockType::STONE;
    }

    void plantTree(Chunk& c, int lx, int topY, int lz, bool birch) {
        // keep trees away from chunk edges so trunk+leaves never need to spill
        // into a neighbouring (possibly not-yet-generated) chunk.
        if (lx < 2 || lx > CHUNK_SX - 3 || lz < 2 || lz > CHUNK_SZ - 3) return;
        int trunkH = 4 + static_cast<int>(hashToFloat(c.cx * 1000 + lx, 0, c.cz * 1000 + lz, seed) * 3);
        BlockType wood = birch ? BlockType::WOOD_BIRCH : BlockType::WOOD_OAK;
        BlockType leaves = birch ? BlockType::LEAVES_BIRCH : BlockType::LEAVES_OAK;
        for (int i = 1; i <= trunkH; ++i) c.localSet(lx, topY + i, lz, wood);
        int top = topY + trunkH;
        for (int dy = -2; dy <= 1; ++dy) {
            int radius = (dy == 1) ? 1 : 2;
            for (int dx = -radius; dx <= radius; ++dx) {
                for (int dz = -radius; dz <= radius; ++dz) {
                    if (dx == 0 && dz == 0 && dy < 1) continue;
                    if (std::abs(dx) == radius && std::abs(dz) == radius && radius == 2) continue;
                    c.localSet(lx + dx, top + dy, lz + dz, leaves);
                }
            }
        }
    }

    void generateTerrain(Chunk& c) {
        for (int lx = 0; lx < CHUNK_SX; ++lx) {
            for (int lz = 0; lz < CHUNK_SZ; ++lz) {
                int wx = c.cx * CHUNK_SX + lx, wz = c.cz * CHUNK_SZ + lz;
                int height = surfaceHeight(wx, wz);
                double moisture = noise.fbm2((wx + 5000) * 0.01, (wz + 5000) * 0.01, 3, 0.5, 2.0);

                BlockType top = BlockType::GRASS;
                if (height <= SEA_LEVEL + 1) top = BlockType::SAND;
                else if (height >= 80) top = BlockType::SNOW;

                for (int y = 0; y <= height; ++y) {
                    BlockType b;
                    if (y == 0) b = BlockType::BEDROCK;
                    else if (y == 1) b = hashToFloat(wx, y, wz, seed) < 0.5f ? BlockType::BEDROCK : BlockType::STONE;
                    else if (y == height) b = top;
                    else if (y >= height - 3) b = (top == BlockType::SAND) ? BlockType::SAND : BlockType::DIRT;
                    else b = BlockType::STONE;

                    // carve caves (leave a buffer near bedrock and near the surface)
                    if (b == BlockType::STONE && y > 3 && y < height - 5) {
                        double cave = caveNoise.fbm3(wx * 0.07, y * 0.10, wz * 0.07, 3, 0.5, 2.0);
                        if (cave > 0.60) b = BlockType::AIR;
                    }
                    if (b == BlockType::STONE) b = pickOre(wx, y, wz);

                    // occasional decorative variants
                    if (b == BlockType::STONE && hashToFloat(wx, y, wz, seed + 7) < 0.02f) {
                        float variant = hashToFloat(wx, y, wz, seed + 8);
                        b = variant < 0.4f ? BlockType::MOSSY_STONE : (variant < 0.7f ? BlockType::MARBLE : BlockType::BASALT);
                    }

                    c.localSet(lx, y, lz, b);
                }
                for (int y = height + 1; y <= SEA_LEVEL; ++y) c.localSet(lx, y, lz, BlockType::WATER);

                if (top == BlockType::GRASS && hashToFloat(wx, 0, wz, seed + 3) < 0.015f) {
                    plantTree(c, lx, height, lz, moisture < 0.0);
                }
            }
        }
        c.dirty = true;
    }

    void buildMesh(Chunk& c) {
        std::vector<float> verts;
        std::vector<uint32_t> indices;
        verts.reserve(4096);
        indices.reserve(6144);

        for (int lx = 0; lx < CHUNK_SX; ++lx) {
            for (int ly = 0; ly < CHUNK_SY; ++ly) {
                for (int lz = 0; lz < CHUNK_SZ; ++lz) {
                    BlockType b = c.localGet(lx, ly, lz);
                    if (b == BlockType::AIR) continue;
                    int wx = c.cx * CHUNK_SX + lx, wz = c.cz * CHUNK_SZ + lz;
                    glm::vec3 col = blockColor(b);
                    float noiseTint = 0.92f + hashToFloat(wx, ly, wz, seed + 99) * 0.16f;

                    static const glm::ivec3 offs[6] = {
                        {0,1,0}, {0,-1,0}, {1,0,0}, {-1,0,0}, {0,0,1}, {0,0,-1}
                    };
                    for (int f = 0; f < 6; ++f) {
                        glm::ivec3 n = offs[f];
                        BlockType neighbor = getBlock(wx + n.x, ly + n.y, wz + n.z);
                        // skip the face if the neighbour is solid, or if it's the
                        // same transparent material (e.g. water next to water)
                        bool neighborHides = isSolid(neighbor) || (neighbor == b && isTransparent(b));
                        if (neighborHides) continue;

                        uint32_t base = static_cast<uint32_t>(verts.size() / 10);
                        const FaceDef& fd = FACES[f];
                        for (int v = 0; v < 4; ++v) {
                            // world-space position for this chunk's local vertex
                            glm::vec3 pos(wx + fd.corners[v].x, ly + fd.corners[v].y, wz + fd.corners[v].z);
                            verts.push_back(pos.x); verts.push_back(pos.y); verts.push_back(pos.z);
                            verts.push_back(fd.normal.x); verts.push_back(fd.normal.y); verts.push_back(fd.normal.z);
                            verts.push_back(col.r); verts.push_back(col.g); verts.push_back(col.b);
                            verts.push_back(fd.baseShade * noiseTint);
                        }
                        indices.push_back(base + 0); indices.push_back(base + 1); indices.push_back(base + 2);
                        indices.push_back(base + 0); indices.push_back(base + 2); indices.push_back(base + 3);
                    }
                }
            }
        }

        glBindVertexArray(c.vao);
        glBindBuffer(GL_ARRAY_BUFFER, c.vbo);
        glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(float), verts.data(), GL_DYNAMIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, c.ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(uint32_t), indices.data(), GL_DYNAMIC_DRAW);

        GLsizei stride = 10 * sizeof(float);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, stride, (void*)(9 * sizeof(float)));
        glEnableVertexAttribArray(3);
        glBindVertexArray(0);

        c.indexCount = static_cast<GLsizei>(indices.size());
        c.dirty = false;
        c.hasMesh = true;
    }
};
