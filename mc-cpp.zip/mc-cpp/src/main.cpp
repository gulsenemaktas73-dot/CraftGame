// Realistic-ish voxel game in C++ / OpenGL.
// Infinite chunked world, block breaking/placing, day-night cycle, 27 block types.
//
// Controls:
//   WASD          - move
//   Mouse         - look around
//   Space         - jump
//   Left Shift    - sprint
//   Left click    - break block
//   Right click   - place block (currently selected hotbar item)
//   1-9 / scroll  - select hotbar block
//   Esc           - quit

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include <cmath>
#include <sstream>
#include <algorithm>

#include "Shader.h"
#include "Camera.h"
#include "World.h"
#include "Block.h"

// ---------- tunables ----------
static const int   WIN_W = 1280, WIN_H = 720;
static const int   RENDER_DISTANCE = 6;       // in chunks
static const float DAY_LENGTH_SEC  = 600.0f;  // full day/night cycle
static const float WALK_SPEED = 4.3f, SPRINT_SPEED = 7.0f;
static const float JUMP_SPEED = 8.0f, GRAVITY = 22.0f;
static const float PLAYER_HALF_W = 0.3f, PLAYER_HEIGHT = 1.8f, EYE_HEIGHT = 1.62f;

// ---------- global-ish state touched by callbacks ----------
static Camera camera;
static bool firstMouse = true;
static double lastX = WIN_W / 2.0, lastY = WIN_H / 2.0;
static int hotbarSlot = 0;
static bool breakQueued = false, placeQueued = false;
static int fbWidth = WIN_W, fbHeight = WIN_H;

void framebufferSizeCallback(GLFWwindow*, int w, int h) {
    fbWidth = w; fbHeight = h;
    glViewport(0, 0, w, h);
}

void mouseCallback(GLFWwindow*, double xpos, double ypos) {
    if (firstMouse) { lastX = xpos; lastY = ypos; firstMouse = false; }
    double dx = xpos - lastX, dy = ypos - lastY;
    lastX = xpos; lastY = ypos;
    camera.processMouse(dx, dy);
}

void mouseButtonCallback(GLFWwindow*, int button, int action, int) {
    if (action != GLFW_PRESS) return;
    if (button == GLFW_MOUSE_BUTTON_LEFT) breakQueued = true;
    if (button == GLFW_MOUSE_BUTTON_RIGHT) placeQueued = true;
}

void scrollCallback(GLFWwindow*, double, double yoff) {
    hotbarSlot = ((hotbarSlot - (yoff > 0 ? 1 : -1)) % 9 + 9) % 9;
}

void keyCallback(GLFWwindow* window, int key, int, int action, int) {
    if (action != GLFW_PRESS) return;
    if (key == GLFW_KEY_ESCAPE) glfwSetWindowShouldClose(window, GLFW_TRUE);
    if (key >= GLFW_KEY_1 && key <= GLFW_KEY_9) hotbarSlot = key - GLFW_KEY_1;
}

const char* blockNameTR(BlockType b) {
    switch (b) {
        case BlockType::DIRT: return "Toprak";
        case BlockType::STONE: return "Tas";
        case BlockType::SAND: return "Kum";
        case BlockType::WOOD_OAK: return "Kutuk";
        case BlockType::PLANKS: return "Tahta";
        case BlockType::GLASS: return "Cam";
        case BlockType::BRICK: return "Tugla";
        case BlockType::SNOW: return "Kar";
        case BlockType::OBSIDIAN: return "Obsidyen";
        default: return "?";
    }
}

// Axis-aligned box vs. voxel world collision test.
bool boxCollides(World& world, const glm::vec3& pos) {
    glm::vec3 mn(pos.x - PLAYER_HALF_W, pos.y, pos.z - PLAYER_HALF_W);
    glm::vec3 mx(pos.x + PLAYER_HALF_W, pos.y + PLAYER_HEIGHT, pos.z + PLAYER_HALF_W);
    int x0 = static_cast<int>(std::floor(mn.x)), x1 = static_cast<int>(std::floor(mx.x));
    int y0 = static_cast<int>(std::floor(mn.y)), y1 = static_cast<int>(std::floor(mx.y));
    int z0 = static_cast<int>(std::floor(mn.z)), z1 = static_cast<int>(std::floor(mx.z));
    for (int x = x0; x <= x1; ++x)
        for (int y = y0; y <= y1; ++y)
            for (int z = z0; z <= z1; ++z)
                if (isSolid(world.getBlock(x, y, z))) return true;
    return false;
}

int main() {
    if (!glfwInit()) { std::cerr << "GLFW init failed\n"; return -1; }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    GLFWwindow* window = glfwCreateWindow(WIN_W, WIN_H, "Voxel Dunyasi - C++/OpenGL", nullptr, nullptr);
    if (!window) { std::cerr << "Window creation failed\n"; glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);
    glfwSetCursorPosCallback(window, mouseCallback);
    glfwSetMouseButtonCallback(window, mouseButtonCallback);
    glfwSetScrollCallback(window, scrollCallback);
    glfwSetKeyCallback(window, keyCallback);

    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) { std::cerr << "GLEW init failed\n"; return -1; }

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    Shader chunkShader;
    chunkShader.build(CHUNK_VERT_SRC, CHUNK_FRAG_SRC);

    World world(20260726u);

    // spawn the player on solid ground near the origin
    camera.position = glm::vec3(0.5f, static_cast<float>(world.highestSolidY(0, 0) + 2), 0.5f);
    glm::vec3 velocity(0.0f);
    bool onGround = false;

    double lastFrame = glfwGetTime();
    double titleTimer = 0.0;

    while (!glfwWindowShouldClose(window)) {
        double now = glfwGetTime();
        float dt = static_cast<float>(now - lastFrame);
        dt = std::min(dt, 0.05f); // clamp to avoid huge steps after a stall
        lastFrame = now;

        glfwPollEvents();

        // ---- input: movement ----
        glm::vec3 f = camera.front(); f.y = 0; if (glm::length(f) > 0.0001f) f = glm::normalize(f);
        glm::vec3 r = camera.right();
        glm::vec3 wish(0.0f);
        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) wish += f;
        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) wish -= f;
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) wish += r;
        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) wish -= r;
        if (glm::length(wish) > 0.0001f) wish = glm::normalize(wish);
        bool sprinting = glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS;
        float speed = sprinting ? SPRINT_SPEED : WALK_SPEED;

        velocity.x = wish.x * speed;
        velocity.z = wish.z * speed;
        if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS && onGround) {
            velocity.y = JUMP_SPEED;
            onGround = false;
        }
        velocity.y -= GRAVITY * dt;

        // ---- swept per-axis collision ----
        glm::vec3 pos = camera.position;
        glm::vec3 tryPos = pos; tryPos.x += velocity.x * dt;
        if (!boxCollides(world, tryPos)) pos.x = tryPos.x;
        tryPos = pos; tryPos.z += velocity.z * dt;
        if (!boxCollides(world, tryPos)) pos.z = tryPos.z;
        tryPos = pos; tryPos.y += velocity.y * dt;
        if (!boxCollides(world, tryPos)) {
            pos.y = tryPos.y;
            onGround = false;
        } else {
            if (velocity.y < 0) onGround = true;
            velocity.y = 0;
        }
        camera.position = pos;

        // ---- break / place ----
        RaycastHit hit = world.raycast(camera.position + glm::vec3(0, EYE_HEIGHT, 0), camera.front(), 6.0f);
        if (breakQueued) {
            if (hit.hit) world.setBlock(hit.block.x, hit.block.y, hit.block.z, BlockType::AIR);
            breakQueued = false;
        }
        if (placeQueued) {
            if (hit.hit) {
                glm::vec3 c(hit.prev.x + 0.5f, hit.prev.y + 0.0f, hit.prev.z + 0.5f);
                bool overlapsPlayer =
                    std::abs(c.x - camera.position.x) < PLAYER_HALF_W + 0.5f &&
                    std::abs(c.z - camera.position.z) < PLAYER_HALF_W + 0.5f &&
                    hit.prev.y >= camera.position.y - 0.1f && hit.prev.y <= camera.position.y + PLAYER_HEIGHT;
                if (!overlapsPlayer) world.setBlock(hit.prev.x, hit.prev.y, hit.prev.z, hotbarBlock(hotbarSlot));
            }
            placeQueued = false;
        }

        world.update(camera.position, RENDER_DISTANCE);

        // ---- day/night cycle ----
        float t = std::fmod(static_cast<float>(now), DAY_LENGTH_SEC) / DAY_LENGTH_SEC;
        float sunAngle = t * 2.0f * 3.14159265f;
        glm::vec3 sunDir = glm::normalize(glm::vec3(std::cos(sunAngle), std::sin(sunAngle), 0.35f));
        float dayFactor = std::clamp((std::sin(sunAngle) + 0.25f) / 1.1f, 0.06f, 1.0f);

        glm::vec3 dayColor(0.53f, 0.75f, 0.95f), nightColor(0.02f, 0.03f, 0.08f);
        glm::vec3 skyColor = glm::mix(nightColor, dayColor, dayFactor);
        glm::vec3 ambient = glm::mix(glm::vec3(0.06f, 0.07f, 0.10f), glm::vec3(0.35f, 0.37f, 0.40f), dayFactor);
        glm::vec3 sunColor = glm::vec3(1.0f, 0.97f, 0.88f) * dayFactor;

        // ---- render ----
        glClearColor(skyColor.r, skyColor.g, skyColor.b, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glm::mat4 proj = glm::perspective(glm::radians(75.0f),
            static_cast<float>(fbWidth) / static_cast<float>(std::max(fbHeight, 1)), 0.1f, 400.0f);
        glm::mat4 view = camera.viewMatrix(EYE_HEIGHT);

        chunkShader.use();
        chunkShader.setMat4("uView", view);
        chunkShader.setMat4("uProj", proj);
        chunkShader.setVec3("uSunDir", sunDir);
        chunkShader.setVec3("uSunColor", sunColor);
        chunkShader.setVec3("uAmbient", ambient);
        chunkShader.setVec3("uFogColor", skyColor);
        chunkShader.setFloat("uFogDensity", 1.4f / (RENDER_DISTANCE * CHUNK_SX));

        world.render(chunkShader);

        glfwSwapBuffers(window);

        // ---- title bar HUD (simplest possible on-screen info without a text renderer) ----
        titleTimer += dt;
        if (titleTimer > 0.25) {
            titleTimer = 0;
            std::ostringstream ss;
            ss << "Voxel Dunyasi  |  FPS: " << static_cast<int>(1.0f / std::max(dt, 0.0001f))
               << "  |  Blok: " << blockNameTR(hotbarBlock(hotbarSlot)) << " (" << (hotbarSlot + 1) << "/9)"
               << "  |  Pos: " << static_cast<int>(camera.position.x) << "," << static_cast<int>(camera.position.y)
               << "," << static_cast<int>(camera.position.z)
               << "  |  " << (dayFactor > 0.5f ? "Gunduz" : "Gece");
            glfwSetWindowTitle(window, ss.str().c_str());
        }
    }

    glfwTerminate();
    return 0;
}
