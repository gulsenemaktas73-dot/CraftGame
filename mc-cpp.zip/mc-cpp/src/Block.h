#pragma once
#include <cstdint>
#include <glm/glm.hpp>

// 27 block types -- noticeably more variety than vanilla's core terrain set.
enum class BlockType : uint8_t {
    AIR = 0,
    GRASS, DIRT, STONE, SAND, GRAVEL, CLAY,
    WATER,
    WOOD_OAK, LEAVES_OAK, WOOD_BIRCH, LEAVES_BIRCH,
    BEDROCK,
    COAL_ORE, IRON_ORE, GOLD_ORE, DIAMOND_ORE, EMERALD_ORE, REDSTONE_ORE,
    SNOW, ICE,
    GLASS,
    PLANKS, BRICK,
    OBSIDIAN, MOSSY_STONE, MARBLE, BASALT,
    COUNT
};

inline bool isSolid(BlockType b) {
    return b != BlockType::AIR && b != BlockType::WATER && b != BlockType::GLASS;
}

inline bool isTransparent(BlockType b) {
    return b == BlockType::AIR || b == BlockType::WATER || b == BlockType::GLASS ||
           b == BlockType::LEAVES_OAK || b == BlockType::LEAVES_BIRCH;
}

// Base color per block type (RGB 0..1). Rendering adds per-face shading,
// per-block noise variation and fog on top of this for a less "flat" look.
inline glm::vec3 blockColor(BlockType b) {
    switch (b) {
        case BlockType::GRASS:        return {0.36f, 0.62f, 0.28f};
        case BlockType::DIRT:         return {0.45f, 0.31f, 0.20f};
        case BlockType::STONE:        return {0.52f, 0.52f, 0.54f};
        case BlockType::SAND:         return {0.86f, 0.79f, 0.55f};
        case BlockType::GRAVEL:       return {0.58f, 0.55f, 0.52f};
        case BlockType::CLAY:         return {0.62f, 0.63f, 0.68f};
        case BlockType::WATER:        return {0.16f, 0.40f, 0.68f};
        case BlockType::WOOD_OAK:     return {0.42f, 0.29f, 0.16f};
        case BlockType::LEAVES_OAK:   return {0.20f, 0.45f, 0.16f};
        case BlockType::WOOD_BIRCH:   return {0.80f, 0.77f, 0.66f};
        case BlockType::LEAVES_BIRCH: return {0.55f, 0.68f, 0.30f};
        case BlockType::BEDROCK:      return {0.12f, 0.12f, 0.13f};
        case BlockType::COAL_ORE:     return {0.30f, 0.30f, 0.32f};
        case BlockType::IRON_ORE:     return {0.72f, 0.60f, 0.52f};
        case BlockType::GOLD_ORE:     return {0.85f, 0.72f, 0.20f};
        case BlockType::DIAMOND_ORE:  return {0.40f, 0.85f, 0.85f};
        case BlockType::EMERALD_ORE:  return {0.20f, 0.80f, 0.45f};
        case BlockType::REDSTONE_ORE: return {0.75f, 0.15f, 0.12f};
        case BlockType::SNOW:         return {0.96f, 0.97f, 0.98f};
        case BlockType::ICE:          return {0.70f, 0.85f, 0.95f};
        case BlockType::GLASS:        return {0.80f, 0.92f, 0.95f};
        case BlockType::PLANKS:       return {0.63f, 0.47f, 0.28f};
        case BlockType::BRICK:        return {0.62f, 0.27f, 0.20f};
        case BlockType::OBSIDIAN:     return {0.10f, 0.06f, 0.16f};
        case BlockType::MOSSY_STONE:  return {0.40f, 0.48f, 0.32f};
        case BlockType::MARBLE:       return {0.85f, 0.83f, 0.80f};
        case BlockType::BASALT:       return {0.24f, 0.24f, 0.27f};
        default:                      return {1.0f, 0.0f, 1.0f}; // magenta = error
    }
}

// Blocks the player can place, cycled through the 1-9 hotbar.
inline BlockType hotbarBlock(int slot) {
    static const BlockType items[9] = {
        BlockType::DIRT, BlockType::STONE, BlockType::SAND, BlockType::WOOD_OAK,
        BlockType::PLANKS, BlockType::GLASS, BlockType::BRICK, BlockType::SNOW,
        BlockType::OBSIDIAN
    };
    return items[slot % 9];
}
